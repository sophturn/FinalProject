class city1:
  print ("Welcome to...")
  print ("Here you may battle to win medals to find your parents")