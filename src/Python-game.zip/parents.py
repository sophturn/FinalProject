#Alan Pham
#mc finds their parents
class Parents:
  print("")