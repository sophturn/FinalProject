#alan pham
#cave is to find parents
import time
import parents
class Cave:
  def work():
    print ("you enter cave find messy...")
#parents()