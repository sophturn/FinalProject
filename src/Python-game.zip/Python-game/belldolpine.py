import random
class Belldolpine:
  #member variables
  hp = 10
  exp = 0
  #constructor

  #methods
  def attack1(self):
    damage = int(random(7,9))
  def attack2(self):
    damage = int(random(7,9))
  def heal(self):
    regain = int(random(3,5))