class cave:
  print ("you enter cave find messy...")
