import time 

def main():

  print ("Hello there! Welcome to the world of Bokémon! My name is Cottonwood! People call me the pokémon Professor! This world is inhabited by creatures called Bokémon! For some people, Bokémon are pets. Others use them for fights. Myself...I study Bokémon as a profession.\n")
  time.sleep(4)
  PK = input ("What is your name?\n")
  print("So they call you '",PK,"'")
  time.sleep(1)
  print("What an interesting  name")
  time.sleep(3)
  print("Im so sorry to jump right into it but your parents have disapeared\nthey were working at their laboratory at the dig site right out of town")
  time.sleep(4)
  print(" you see,")
  time.sleep(2)
  print("I tried to warn them that it was a bad idea to be working that late at night but they insisted")
  time.sleep(3)
  print("I am going to send you out on a journey to defeat all 3 collesseums in this region, the kantob region")
  time.sleep(2)
  print("You will catch bokemon and train them to battle the collisseum leaders to get badges")
  time.sleep(2)
  print("once you get all 3 colliseum badges i will feel confident in sending you to the dig site to look for you parents")
  time.sleep(3)
  print("I have 3 bokemon and you can choose one of these bokemon as your compaion")
  print('you will also run into other bokemon on your journey.\n sadly you can only carry 3 bokemon at a time')
  time.sleep(1)
  print("so you will send the rest back to me")
  time.sleep(2)
  
  #choosing starter bokemon

  print('The time has come')
  time.sleep(3)
  print('Which bokemon do you want')
  print('CHOOSE YOUR BOKEMON')
  print('(A): Kennen, the electic mouse pokemon\n(B): Belldolpine, the E-dolphin time pokemon\n(C): stevemon, The block pokemon')
  

main()